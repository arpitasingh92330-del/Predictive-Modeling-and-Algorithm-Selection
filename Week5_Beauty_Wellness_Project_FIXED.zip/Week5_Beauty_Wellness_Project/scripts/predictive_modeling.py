"""Week 5 predictive modeling demo for the synthetic beauty reviews dataset.

Target: low_rating = 1 when the observed star rating is 1 or 2, else 0.
This is a teaching demonstration, not a model for real customer decisions.
The raw rating and any rating-derived fields are excluded from predictors.
"""
from pathlib import Path
import json
import warnings
warnings.filterwarnings("ignore", message="Precision is ill-defined*", category=UserWarning)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, average_precision_score, balanced_accuracy_score,
    classification_report, confusion_matrix, f1_score, precision_score,
    recall_score, roc_auc_score, RocCurveDisplay, PrecisionRecallDisplay,
)
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier, plot_tree

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "input" / "cleaned_engineered_reviews_synthetic.csv"
METRICS = ROOT / "outputs" / "metrics"
FIGURES = ROOT / "outputs" / "figures"
for p in (METRICS, FIGURES):
    p.mkdir(parents=True, exist_ok=True)

if not INPUT.exists():
    raise FileNotFoundError(f"Input CSV not found: {INPUT}")

df = pd.read_csv(INPUT)
required = {"rating", "price_inr", "size_ml", "category", "review_text"}
missing = sorted(required - set(df.columns))
if missing:
    raise ValueError(f"Required columns missing from input: {missing}")

# Basic validation is reported; this script doesn't silently alter invalid labels.
df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
df = df.loc[df["rating"].between(1, 5)].copy()
df["low_rating"] = (df["rating"] <= 2).astype(int)

# Only fields plausibly available from product metadata and review text are used.
# Excluded: rating, rating_group, rating_x_irritation_theme, review_id/product_id,
# and other direct identifiers or label-derived fields.
NUMERIC_CANDIDATES = [
    "price_inr", "size_ml", "price_per_100ml", "review_length_chars",
    "review_word_count", "verified_purchase", "review_month", "is_weekend",
    "positive_word_count", "negative_word_count", "lexicon_sentiment_score",
    "mentions_hydration", "mentions_texture", "mentions_irritation",
    "mentions_fragrance", "mentions_packaging", "mentions_shade_match",
    "mentions_wear_time",
]
CATEGORICAL_CANDIDATES = ["category", "brand", "price_band", "primary_theme", "review_weekday"]
NUMERIC = [c for c in NUMERIC_CANDIDATES if c in df.columns]
CATEGORICAL = [c for c in CATEGORICAL_CANDIDATES if c in df.columns]
if not NUMERIC and not CATEGORICAL:
    raise ValueError("No eligible predictive features available.")
for c in NUMERIC:
    df[c] = pd.to_numeric(df[c], errors="coerce")
for c in CATEGORICAL:
    df[c] = df[c].astype("string").fillna("Unknown")

X = df[NUMERIC + CATEGORICAL].copy()
y = df["low_rating"].astype(int)

if y.nunique() < 2 or int(y.sum()) < 8:
    raise ValueError("Insufficient low-rating examples for a meaningful stratified demo.")

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

numeric_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
    ("scaler", StandardScaler()),
])
categorical_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=True)),
])
transformers = []
if NUMERIC:
    transformers.append(("numeric", numeric_pipe, NUMERIC))
if CATEGORICAL:
    transformers.append(("categorical", categorical_pipe, CATEGORICAL))
preprocess = ColumnTransformer(transformers=transformers, remainder="drop")

models = {
    "Dummy majority baseline": DummyClassifier(strategy="most_frequent"),
    "Logistic regression": LogisticRegression(
        max_iter=2000, class_weight="balanced", solver="liblinear", random_state=42
    ),
    "Shallow decision tree": DecisionTreeClassifier(
        max_depth=3, min_samples_leaf=8, class_weight="balanced", random_state=42
    ),
}

# Keep the holdout set out of model selection; CV uses only the training partition.
min_class_train = int(y_train.value_counts().min())
n_splits = min(4, min_class_train)
if n_splits < 2:
    raise ValueError("Not enough minority-class examples in training data for stratified CV.")
cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
scoring = {
    "precision": "precision",
    "recall": "recall",
    "f1": "f1",
    "balanced_accuracy": "balanced_accuracy",
    "average_precision": "average_precision",
    "roc_auc": "roc_auc",
}

rows = []
cv_rows = []
fitted = {}
predicted = {}
for name, estimator in models.items():
    pipe = Pipeline([("preprocess", preprocess), ("model", estimator)])
    fitted[name] = pipe
    cv_results = cross_validate(pipe, X_train, y_train, cv=cv, scoring=scoring, n_jobs=None, error_score="raise")
    for metric in scoring:
        cv_rows.append({
            "model": name,
            "metric": metric,
            "mean": float(np.mean(cv_results[f"test_{metric}"])),
            "std": float(np.std(cv_results[f"test_{metric}"], ddof=1)) if n_splits > 1 else 0.0,
            "folds": n_splits,
        })
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    probs = pipe.predict_proba(X_test)[:, 1] if hasattr(pipe, "predict_proba") else pred.astype(float)
    predicted[name] = (pred, probs)
    rows.append({
        "model": name,
        "test_n": int(len(y_test)),
        "test_low_rating_n": int(y_test.sum()),
        "precision_low_rating": float(precision_score(y_test, pred, zero_division=0)),
        "recall_low_rating": float(recall_score(y_test, pred, zero_division=0)),
        "f1_low_rating": float(f1_score(y_test, pred, zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(y_test, pred)),
        "average_precision_pr_auc": float(average_precision_score(y_test, probs)),
        "roc_auc": float(roc_auc_score(y_test, probs)) if y_test.nunique() > 1 else float("nan"),
        "accuracy_secondary": float(accuracy_score(y_test, pred)),
    })

metrics_df = pd.DataFrame(rows).sort_values("model")
metrics_df.to_csv(METRICS / "holdout_model_comparison.csv", index=False)
pd.DataFrame(cv_rows).to_csv(METRICS / "cross_validation_metrics.csv", index=False)

pred_out = df.loc[X_test.index, [c for c in ["review_id", "product_id", "category", "rating", "low_rating"] if c in df.columns]].copy()
for name, (pred, probs) in predicted.items():
    safe = name.lower().replace(" ", "_")
    pred_out[f"pred_{safe}"] = pred
    pred_out[f"prob_low_{safe}"] = probs
pred_out.to_csv(METRICS / "holdout_predictions.csv", index=False)

# Confusion-matrix charts for the two real candidates (not the trivial baseline).
for name in ["Logistic regression", "Shallow decision tree"]:
    pred, probs = predicted[name]
    cm = confusion_matrix(y_test, pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(5.6, 4.4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1], labels=["Predicted not-low", "Predicted low"])
    ax.set_yticks([0, 1], labels=["Actual not-low", "Actual low"])
    ax.set_title(f"Confusion matrix — {name}\nSynthetic holdout; positive class = rating 1–2")
    for (i, j), val in np.ndenumerate(cm):
        ax.text(j, i, str(val), ha="center", va="center", fontsize=12, fontweight="bold",
                color="white" if val > cm.max() * 0.55 else "black")
    ax.set_xlabel("Prediction")
    ax.set_ylabel("Observed label")
    fig.tight_layout()
    fig.savefig(FIGURES / f"confusion_matrix_{name.lower().replace(' ', '_')}.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

# Test-set metric comparison figure: PR-AUC and recall focus on minority-class usefulness.
plotdf = metrics_df.set_index("model")[["recall_low_rating", "precision_low_rating", "f1_low_rating", "average_precision_pr_auc"]]
fig, ax = plt.subplots(figsize=(9.5, 5.2))
plotdf.plot(kind="bar", ax=ax, ylim=(0, 1), color=["#2B7A78", "#D9A441", "#5B7C99", "#8B5E83"])
ax.set_title("Holdout metrics by model — synthetic dataset")
ax.set_ylabel("Score (0–1)")
ax.set_xlabel("")
ax.tick_params(axis="x", labelrotation=15)
ax.grid(axis="y", alpha=0.25)
ax.legend(loc="best", fontsize=8)
fig.tight_layout()
fig.savefig(FIGURES / "holdout_model_comparison.png", dpi=180, bbox_inches="tight")
plt.close(fig)

# Cross-validation F1 comparison plot; shows fold variability in compact form.
cvdf = pd.DataFrame(cv_rows)
cv_f1 = cvdf[cvdf.metric == "f1"].copy()
fig, ax = plt.subplots(figsize=(8.5, 4.5))
ax.bar(cv_f1.model, cv_f1["mean"], yerr=cv_f1["std"], capsize=4, color=["#8796A5" if "Dummy" in m else ("#2B7A78" if "Logistic" in m else "#D9A441") for m in cv_f1.model])
ax.set_ylim(0, 1)
ax.set_ylabel("F1 for low-rating class")
ax.set_title(f"Training-only stratified CV F1 (mean ± SD, {n_splits} folds)")
ax.tick_params(axis="x", labelrotation=10)
ax.grid(axis="y", alpha=0.25)
fig.tight_layout()
fig.savefig(FIGURES / "cross_validation_f1.png", dpi=180, bbox_inches="tight")
plt.close(fig)

# Small global feature-signal summary (coefficient magnitude for logistic model).
log_model = fitted["Logistic regression"]
feature_signal = []
try:
    names = log_model.named_steps["preprocess"].get_feature_names_out()
    coef = log_model.named_steps["model"].coef_.ravel()
    fi = pd.DataFrame({"feature": names, "coefficient": coef, "abs_coefficient": np.abs(coef)}).sort_values("abs_coefficient", ascending=False)
    fi.to_csv(METRICS / "logistic_coefficients.csv", index=False)
    top = fi.head(12).sort_values("abs_coefficient")
    fig, ax = plt.subplots(figsize=(9.2, 5.6))
    ax.barh(top["feature"], top["coefficient"], color=["#C4554D" if x > 0 else "#2B7A78" for x in top["coefficient"]])
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_title("Largest logistic-regression coefficients (synthetic data)")
    ax.set_xlabel("Coefficient (positive points toward low-rating class)")
    fig.tight_layout()
    fig.savefig(FIGURES / "logistic_top_coefficients.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
except Exception as exc:
    warnings.warn(f"Could not create coefficient chart: {exc}")

summary = {
    "data_status": "synthetic teaching data; not real consumer data",
    "input_file": str(INPUT.relative_to(ROOT)),
    "rows_modelled": int(len(df)),
    "unique_products": int(df["product_id"].nunique()) if "product_id" in df.columns else None,
    "feature_columns": NUMERIC + CATEGORICAL,
    "excluded_columns": ["rating", "rating_group", "rating_x_irritation_theme", "review_id", "product_id"],
    "target_definition": "low_rating = 1 if rating <= 2 else 0",
    "target_counts": {str(int(k)): int(v) for k, v in y.value_counts().sort_index().items()},
    "train_rows": int(len(X_train)),
    "test_rows": int(len(X_test)),
    "test_low_rating_rows": int(y_test.sum()),
    "cross_validation_folds": int(n_splits),
    "holdout_metrics": rows,
    "interpretation": "Holdout and CV scores are illustrative only; 360 synthetic rows and a small low-rating class are not sufficient for claims about real customers or deployment.",
}
(METRICS / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
