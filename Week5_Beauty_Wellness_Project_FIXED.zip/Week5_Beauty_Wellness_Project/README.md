# Week 5 — Predictive Modeling and Algorithm Selection

## Project purpose
This project demonstrates a supervised classification workflow for a beauty & wellness review use case: identify reviews whose observed rating is low (1–2 stars), to support human review triage and aggregated theme analysis.

> **Important data note:** The bundled 360-row CSV is synthetic teaching data derived from the prior-week example. The evaluation metrics are illustrative and must not be interpreted as findings about real consumers or a production-ready model.

## Project structure

- `Week5_Predictive_Modeling_and_Algorithm_Selection.docx` — full report.
- `Week5_Predictive_Modeling_and_Algorithm_Selection.pdf` — view/print backup.
- `data/input/cleaned_engineered_reviews_synthetic.csv` — input dataset (synthetic).
- `scripts/predictive_modeling.py` — end-to-end, leakage-aware modeling workflow.
- `outputs/metrics/holdout_model_comparison.csv` — held-out model metrics.
- `outputs/metrics/cross_validation_metrics.csv` — training-only stratified CV metrics.
- `outputs/metrics/holdout_predictions.csv` — per-row held-out predictions.
- `outputs/metrics/logistic_coefficients.csv` — logistic regression coefficients for inspection.
- `outputs/metrics/run_summary.json` — target counts, split details, predictors and result summary.
- `outputs/figures/` — confusion matrices, model comparison, CV F1 and coefficient plot.
- `docs/` — workflow and 32-hour plan diagrams.
- `submission_description.txt` — description for the online submission form.

## Environment setup
Python 3.10 or later is recommended. In a terminal opened in this project folder:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/predictive_modeling.py
```

The script reads only the included local CSV. It does not connect to external APIs or scrape websites. It writes outputs under `outputs/` and uses a fixed random seed for repeatability.

## Target and leakage policy
`low_rating = 1` when `rating <= 2`; otherwise it is 0. The model excludes the rating itself, the `rating_group` field and `rating_x_irritation_theme`, which is target-derived. Identifiers such as review ID and product ID are also not predictors. Imputers, scaling and categorical encoding are wrapped in scikit-learn pipelines to avoid fitting preprocessing on the holdout data.

## Important limitations
- There are only 34 low-rating examples in 360 rows and only 8 in the fixed test split, so performance estimates are unstable.
- A random review-level split can share products between train and test; the report recommends an additional product-group and temporal validation before real use.
- Keyword sentiment proxies can miss negation, sarcasm, contextual meaning and language variation.
- Do not use this model to make medical, safety, product removal or adverse customer decisions. Any real-world use requires permissioned representative data, governance review and human oversight.
